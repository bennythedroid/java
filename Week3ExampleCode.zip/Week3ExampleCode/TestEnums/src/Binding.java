/**
 * Created by IntelliJ IDEA.
 * User: appleman
 * Date: Oct 20, 2009
 * Time: 2:06:44 PM
 * To change this template use File | Settings | File Templates.
 */
public enum Binding {
    LOW, MEDIUM, HIGH; //; is optional
}
