BindingTest bt = new BindingTest();

bt.nonInitializedEnum();
System.out.println("--------------------------");

bt.lowerCaseEnum();
System.out.println("--------------------------");

bt.printEnumValuesForBinding();
System.out.println("--------------------------");

bt.printEnumValuesForBinding2();
System.out.println("--------------------------");

bt.printEnumCodeForBinding();