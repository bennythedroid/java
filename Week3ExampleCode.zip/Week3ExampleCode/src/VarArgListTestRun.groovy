VarArgListTest valt = new VarArgListTest();
valt.execute();