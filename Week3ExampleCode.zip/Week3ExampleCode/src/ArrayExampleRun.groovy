ArrayExample ae = new ArrayExample();
ae.execute();
System.out.println("\nStarting play\n");
ae.play();