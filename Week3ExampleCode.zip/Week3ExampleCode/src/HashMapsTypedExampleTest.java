import static org.junit.Assert.*;

import org.junit.Test;


public class HashMapsTypedExampleTest {

	@Test
	public void testExecute() {
		(new HashMapsTypedExample()).execute();
	}

}
