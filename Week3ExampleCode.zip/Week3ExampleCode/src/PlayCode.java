import java.util.ArrayList;



public class PlayCode {
	public static void main(String[] args) {
		ArrayList list = new ArrayList();

		int counter = 0;
		counter++;
		System.out.println("counter = " + counter);

		counter = 15 % 60;
		System.out.println("counter = " + counter);
	}
}
