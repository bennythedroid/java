HashMapsTypedExample hmte = new HashMapsTypedExample();
hmte.execute();