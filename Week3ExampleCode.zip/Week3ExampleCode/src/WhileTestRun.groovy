WhileTest wt = 	new WhileTest();
wt.execute();
System.out.println("End Execute");
wt.execute2();

System.out.println("Finished");