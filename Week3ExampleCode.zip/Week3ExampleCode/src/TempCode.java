import java.util.ArrayList;
import java.util.HashMap;

public class TempCode {
	ArrayList names;
	HashMap<String, String[]> keys;
	
	void execute() {
		HashMap phone = null;
	}

}
