ArrayListExample ale = new ArrayListExample();

ale.execute();