HashMapExample hme = new HashMapExample();

hme.execute();