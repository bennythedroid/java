public class TwoClassesInAFile {

}

class AnotherClassInAFile {
}
