

public class ExpressionsDemo {
	static final int counter = 9;
	int counter2;

}
