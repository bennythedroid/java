public class FloatingPointNumbersTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		double number = 0.;
		System.out.println("number=" + number);

		double number2 = .0;
		System.out.println("number=" + number);
	}
}
