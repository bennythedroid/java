

public class BooleanExample {
	boolean err;
	boolean statusOk = true;

	public void printValue() {
		System.out.println("BooleanExample.main()- err=" + err);
		System.out.println("BooleanExample.main()- statusOk=" + statusOk);
	}
}
