

DayTest firstDay = new DayTest(Day.MONDAY);
firstDay.tellItLikeItIs();

DayTest thirdDay = new DayTest(Day.WEDNESDAY);
thirdDay.tellItLikeItIs();

DayTest fifthDay = new DayTest(Day.FRIDAY);
fifthDay.tellItLikeItIs();

DayTest sixthDay = new DayTest(Day.SATURDAY);
sixthDay.tellItLikeItIs();

DayTest seventhDay = new DayTest(Day.SUNDAY);
seventhDay.tellItLikeItIs();