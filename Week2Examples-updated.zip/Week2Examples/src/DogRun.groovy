Dog fred = new Dog();

fred.bark();
fred.bark (10);
fred = new Dog(35);
fred.bark();