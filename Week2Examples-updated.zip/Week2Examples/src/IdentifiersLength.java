

public class IdentifiersLength {
	int counterForTotalComputersInHouse;

	public void runTest() {

	}
}
